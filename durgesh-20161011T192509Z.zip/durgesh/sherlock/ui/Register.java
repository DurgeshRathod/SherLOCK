package durgesh.sherlock.ui;


import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import durgesh.sherlock.R;
import durgesh.sherlock.core.Phone;

public class Register extends Activity {

    String firstSuperHero;
    String secondSuperHero;
    Phone myPhone;
    Button save;
    EditText Rusername,Rpassword,Rconfirmpssword,Rtrustedcontact1,Rtrustedcontact2;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Rusername =(EditText)findViewById(R.id.editText3);
        Rpassword=(EditText)findViewById(R.id.editText4);
        Rconfirmpssword=(EditText)findViewById(R.id.editText5);
        Rtrustedcontact1=(EditText)findViewById(R.id.editText6);
        Rtrustedcontact2 = (EditText) findViewById(R.id.editText7);
        myPhone = new Phone(getApplicationContext());
        save=(Button)findViewById(R.id.button3);

        firstSuperHero = Rtrustedcontact1.getText().toString().trim();
        secondSuperHero = Rtrustedcontact2.getText().toString().trim();
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myPhone.setUsername(Rusername.getText().toString());
                myPhone.setPassword(Rpassword.getText().toString());
                myPhone.registerPhone(firstSuperHero,secondSuperHero);


                Intent i2 = new Intent(getApplicationContext(), Login.class);
                startActivity(i2);
            }
        });

    }
}
