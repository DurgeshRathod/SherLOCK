package durgesh.sherlock.ui;

import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Vibrator;
import android.support.v4.view.LayoutInflaterFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
 import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HeaderViewListAdapter;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Toolbar;

import durgesh.sherlock.R;
import durgesh.sherlock.core.Phone;

public class Status extends Activity {


    Phone myPhone;
    TelephonyManager tm;

    Vibrator vibrator;
    Toolbar toolbar;
    Button mStatus , changepassword;

    int READ_SIM_SERIAL_NUMBER_PERMISSION;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);

        tm=(TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        mStatus=(Button)findViewById(R.id.button5);
        changepassword=(Button)findViewById(R.id.button4);
     vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

      //  toolbar = (Toolbar) findViewById(R.id.myToolbar);
        myPhone = new Phone(getApplicationContext());

        Toast.makeText(this, "click the button to ON/OFF protection"+"isProtectionON()="
                +myPhone.isProtectionOn()
                +"\n serial no-"+tm.getSimSerialNumber()+"" , Toast.LENGTH_SHORT).show();
            if (myPhone.isProtectionOn())
            {
                mStatus.setText("Turn OFF Protection");
            }
        else
            {
                mStatus.setText("Turn ON Protection");
            }



   }




    private  void initND()
    {
    }


//-------------------------------------------------------------------------------------------------


    private void showPin(Button mStatus) {
    }




//------------------------------------------------------------------------------------------------





    //---------------------------------------------------------------------------------------------
    private void showWarning()
    {

    }



    //----------------------------------------------------------------------------------------------

    public void turnonoff(View view) {
        myPhone.toast("i am in toogle protection click");
        if(myPhone.isProtectionOn())
        {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("You are about to turn off sherLOCK protection. Do you want to proceed?");

            alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface arg0, int arg1) {
                    Toast.makeText(Status.this,"You clicked yes button",Toast.LENGTH_LONG).show();
                    mStatus.setText("Turn ON Security");
                    myPhone.disableProtection();
                }
            });

            alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();



        }
        else
        {
            mStatus.setText("Turn OFF Security");
            // Read SIM Serial number
            myPhone.setSIMId(tm.getSimSerialNumber());

            //   initND();


        }


    }

    public void changePassword(View view) {

        LayoutInflater factory= LayoutInflater.from(this);

        String oldPassword = myPhone.getPassword();
        final View textEntryView=factory.inflate(R.layout.activity_text_entry, null);

        final EditText opass = (EditText) textEntryView.findViewById(R.id.editText8);
        final EditText npass = (EditText) textEntryView.findViewById(R.id.editText9);
        final EditText cpass = (EditText) textEntryView.findViewById(R.id.editText10);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Change Password");
        alert.setView(textEntryView);
        alert.setPositiveButton("save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String s = npass.getText().toString();
                if ((myPhone.getPassword().equals( opass.getText().toString())  )&& (npass.getText().toString().equals( cpass.getText().toString())) ) {
                    myPhone.setPassword(s);
                    myPhone.toast("new password is " + s );
                }
            }
        });
        alert.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = alert.create();
        alertDialog.show();

    }

    public void showFeatures(View view) {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Features  ");
        alert.setMessage("Now you can:\n\t-get SIM change alerts\n\t-track your phone with a SMS" +
                "\n\t-start siren with another SMS");
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });



        AlertDialog alertDialog = alert.create();
        alertDialog.show();


    }


    //----------------------------------------------------------------------------------------------


}
