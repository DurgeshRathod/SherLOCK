package durgesh.sherlock.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.SyncStateContract;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import durgesh.sherlock.R;
import durgesh.sherlock.core.Phone;

public class Login extends Activity {
    EditText username;
    EditText password;
    Button login;
    Button register;
    Button changepassword;
    Phone myPhone;
    String pass,uname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login = (Button) findViewById(R.id.button);
        register = (Button) findViewById(R.id.button2);
        username = (EditText) findViewById(R.id.editText);
        password =(EditText) findViewById(R.id.editText2);
        myPhone = new Phone(getApplicationContext());
        changepassword=(Button)findViewById(R.id.button9);

        if(myPhone.isRegistered())
        {
            changepassword.setEnabled(true);
        }
        else
        {
            changepassword.setEnabled(false);
        }
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(  new Intent(Login.this, Register.class) );
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (authenticate()) {
                    startActivity(new Intent(Login.this, Status.class));
                    Login.this.finish();

                } else {
                    //invalid details
                    pass= myPhone.getPassword();
                    Toast.makeText(getApplicationContext(),"wrong password"+pass+"",Toast.LENGTH_LONG).show();
                }
            }
        });




    }

    private boolean authenticate() {
        // returns true if user entered correct password

        pass = password.getText().toString().trim();
        return (pass.equals(myPhone.getPassword()));
    }

    public void changePassword(View view) {


        LayoutInflater factory= LayoutInflater.from(this);

        String oldPassword = myPhone.getPassword();
        final View textEntryView=factory.inflate(R.layout.activity_text_entry, null);

        final EditText opass = (EditText) textEntryView.findViewById(R.id.editText8);
        final EditText npass = (EditText) textEntryView.findViewById(R.id.editText9);
        final EditText cpass = (EditText) textEntryView.findViewById(R.id.editText10);

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Change Password");
        alert.setView(textEntryView);
        alert.setPositiveButton("save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String s = npass.getText().toString();
                if ((myPhone.getPassword().equals( opass.getText().toString())  )&& (npass.getText().toString().equals( cpass.getText().toString())) ) {
                    myPhone.setPassword(s);
                    myPhone.toast("new password is " + s );
                }
            }
        });
        alert.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = alert.create();
        alertDialog.show();

    }
}
