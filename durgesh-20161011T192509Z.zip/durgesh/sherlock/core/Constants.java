package durgesh.sherlock.core;


/**
 * Created by Durgesh on 4/6/2016.
 */
public class Constants {


    public static final String PREFS = "sherlockAppPrefs";
    public static final String ALREADY_REGISTERED = "ALREADY REGISTERED";
    public static final String USERNAME = "USER NAME";
    public static final String PASSWORD = "PASSWORD";
    public static final String FIRST_SUPERHERO = "FIRST SUPERHERO";
    public static final String SECOND_SUPERHERO = "SECOND SUPERHERO";
    public static final String PIN = "PIN";
    public static final String PROTECTION_ON = "PROTECTION ON";
    public static final String SIM_ID = "Sim id";
    public static final String ALERT_MODE = "alert mode";
    public static final String NUM_UPDATES = "number of sms updates";
    public static final String TRACK = "track";
    public static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    public static final String DISPLAY_ACCOUNT_CONFIRMATION = "displayConfirmation";


}
